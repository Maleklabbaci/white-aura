import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { Language } from '../utils/translations';
import { supabase } from '../lib/supabase';

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  customer: {
    fullName: string;
    phone: string;
    address: string;
    wilaya: string;
    commune: string;
  };
  status: 'En attente' | 'Expédiée' | 'Livrée';
  date: string;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  products: Product[];
  loadingProducts: boolean;
  addProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;
  updateProductStock: (id: string, newStock: number) => void;
  cart: CartItem[];
  addToCart: (p: Product) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  orders: Order[];
  addOrder: (order: Order) => void;
  updateOrderStatus: (id: string, status: Order['status']) => void;
  isCartOpen: boolean;
  setIsCartOpen: (v: boolean) => void;
  isAuthOpen: boolean;
  setIsAuthOpen: (v: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const rowToProduct = (row: any): Product => ({
  id: row.id,
  name: row.name,
  description: row.description,
  price: row.price,
  imageUrl: row.image_url,
  images: row.images ?? [],
  category: row.category,
  isNew: row.is_new ?? false,
  stock: row.stock,
});

const rowToOrder = (row: any): Order => ({
  id: row.id,
  items: row.items,
  total: row.total,
  customer: {
    fullName: row.customer_full_name,
    phone: row.customer_phone,
    address: row.customer_address,
    wilaya: row.customer_wilaya,
    commune: row.customer_commune,
  },
  status: row.status,
  date: row.date,
});

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('white_aura_language') as Language) || 'fr';
  });

  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('white_aura_cart');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });

  useEffect(() => {
    localStorage.setItem('white_aura_language', language);
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    try { localStorage.setItem('white_aura_cart', JSON.stringify(cart)); } catch {}
  }, [cart]);

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      setLoadingProducts(true);
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) console.error('Error fetching products:', error);
      else setProducts((data ?? []).map(rowToProduct));
      setLoadingProducts(false);
    };
    fetchProducts();

    const channel = supabase
      .channel('products-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, fetchProducts)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  // Fetch orders
  useEffect(() => {
    const fetchOrders = async () => {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('date', { ascending: false });
      if (error) console.error('Error fetching orders:', error);
      else setOrders((data ?? []).map(rowToOrder));
    };
    fetchOrders();

    const channel = supabase
      .channel('orders-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, fetchOrders)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const addProduct = async (p: Product) => {
    const { data, error } = await supabase.from('products').insert([{
      name: p.name,
      description: p.description,
      price: p.price,
      image_url: p.imageUrl,
      images: p.images ?? [],
      category: p.category,
      is_new: p.isNew ?? false,
      stock: p.stock,
    }]).select().single();

    if (error) {
      console.error('Error adding product:', error);
      window.dispatchEvent(new CustomEvent('show-toast', { detail: '❌ Erreur lors de l\'ajout' }));
    } else {
      setProducts(prev => [rowToProduct(data), ...prev]);
    }
  };

  const deleteProduct = async (id: string) => {
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (!error) {
      setProducts(prev => prev.filter(p => p.id !== id));
      setCart(prev => prev.filter(item => item.id !== id));
    }
  };

  const updateProductStock = async (id: string, newStock: number) => {
    const { error } = await supabase.from('products').update({ stock: newStock }).eq('id', id);
    if (!error) setProducts(prev => prev.map(p => p.id === id ? { ...p, stock: newStock } : p));
  };

  const addToCart = (p: Product) => {
    if (p.stock <= 0) {
      window.dispatchEvent(new CustomEvent('show-toast', { detail: 'Produit en rupture de stock' }));
      return;
    }
    setCart(prev => {
      const existing = prev.find(item => item.id === p.id);
      if (existing) {
        if (existing.quantity >= p.stock) {
          window.dispatchEvent(new CustomEvent('show-toast', { detail: 'Stock maximum atteint' }));
          return prev;
        }
        return prev.map(item => item.id === p.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...p, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => setCart(prev => prev.filter(item => item.id !== id));

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) { removeFromCart(id); return; }
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity } : item));
  };

  const clearCart = () => setCart([]);

  const addOrder = async (order: Order) => {
    const { error } = await supabase.from('orders').insert([{
      id: order.id,
      items: order.items,
      total: order.total,
      customer_full_name: order.customer.fullName,
      customer_phone: order.customer.phone,
      customer_address: order.customer.address,
      customer_wilaya: order.customer.wilaya,
      customer_commune: order.customer.commune,
      status: order.status,
      date: order.date,
    }]);
    if (error) console.error('Error adding order:', error);
    else setOrders(prev => [order, ...prev]);
  };

  const updateOrderStatus = async (id: string, status: Order['status']) => {
    const { error } = await supabase.from('orders').update({ status }).eq('id', id);
    if (!error) setOrders(prev => prev.map(o => o.id === id ? { ...o, status } : o));
  };

  return (
    <AppContext.Provider value={{
      language, setLanguage,
      products, loadingProducts, addProduct, deleteProduct, updateProductStock,
      cart, addToCart, removeFromCart, updateQuantity, clearCart,
      orders, addOrder, updateOrderStatus,
      isCartOpen, setIsCartOpen,
      isAuthOpen, setIsAuthOpen,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
};
